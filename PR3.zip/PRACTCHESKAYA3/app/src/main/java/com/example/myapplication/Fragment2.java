package com.example.myapplication;


import androidx.fragment.app.Fragment;

public class Fragment2 extends Fragment {
    public Fragment2() {
        super(R.layout.fragment2);
    }
}
