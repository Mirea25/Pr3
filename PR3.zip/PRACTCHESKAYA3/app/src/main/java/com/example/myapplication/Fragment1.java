package com.example.myapplication;

import androidx.fragment.app.Fragment;

public class Fragment1 extends Fragment {
    public Fragment1() {
        super(R.layout.fragment1);
    }
}
